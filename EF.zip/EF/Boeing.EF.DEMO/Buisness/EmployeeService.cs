﻿using System;
using System.Collections.Generic;

using Boeing.EF.Repository.EDM;
using Boeing.EF.Repository.Repositries;

using Newtonsoft.Json;

namespace Boeing.EF.DEMO.Buisness
{
    public class EmployeeService : IEmployeeService
    {
        private bool disposed = false;
        private readonly IEmployeeRepository employeeRepository;
        public EmployeeService(IEmployeeRepository _employeeRepository) => this.employeeRepository = _employeeRepository;
        public int Save()
        {
            List<City> cities = new List<City>
            {
                new City
                {
                    Name = "BLR",
                },
                new City
                {

                    Name = "Del",

                }
            };
            Employee employee = new Employee
            {
                Name = "Ahmar",
                Email = "ahmar.husain@boeing.com",
                Department = new Department
                {
                    DeptName = "IT&DA",
                    Cities = cities
                }
            };
            int returnValue = this.employeeRepository.Save(employee);
            return returnValue;
        }
        public int SaveAll()
        {
            List<City> cities = new List<City>
            {
                new City
                {

                    Name = "BLR",

                },
                new City
                {

                    Name = "Del",

                }
            };
            List<Employee> employees = new List<Employee>
            {
                new Employee
                {

                    Email = "ahmar.husain@boeing.com",
                    Name = "Ahmar",
                    Phone = 123,
                    Department = new Department
                    {

                        DeptName = "IT&DA",
                        Cities = cities

                    }

                }
            };
            List<City> Mcities = new List<City>
            {
                new City
                {

                    Name = "HYD",

                },
                new City
                {

                    Name = "CHE",

                }
            };
            employees.Add(new Employee
            {

                Email = "manish.kumar@boeing.com",
                Name = "Manish",
                Phone = 3223,
                Department = new Department
                {

                    DeptName = "PCF",
                    Cities = Mcities

                }

            });
            int returnValue = this.employeeRepository.Save(employees);
            return returnValue;
        }
        public Employee Get(int empId)
        {
            Employee employee = this.employeeRepository.Get(1);

            Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(employee, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                Formatting = Formatting.Indented
            }));
            return employee;
        }
        public List<Employee> Get()
        {
            List<Employee> employees = this.employeeRepository.Get();
            Console.WriteLine(Newtonsoft.Json.JsonConvert.SerializeObject(employees, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                Formatting = Formatting.Indented
            }));
            return employees;
        }
        public int UpdateEmployee(int id)
        {
            int returnVal = this.employeeRepository.UpdateEmployee(id, "Ahmar Husain");
            return returnVal;
        }
        public int DeleteEmployee(int id)
        {
            int returnVal = this.employeeRepository.DeleteEmployee(id);
            return returnVal;
        }
        public int DeleteEmployees()
        {
            int returnVal = this.employeeRepository.DeleteEmployees();
            return returnVal;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    if (this.employeeRepository != null)
                    {
                        this.employeeRepository.Dispose();
                    }
                }

                this.disposed = true;
            }
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
