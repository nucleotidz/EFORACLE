﻿using System;
using System.Collections.Generic;
using System.Text;

using Boeing.EF.Repository.EDM;

namespace Boeing.EF.DEMO.Buisness
{
  public  interface IEmployeeService:IDisposable
    {
        int Save();
        int SaveAll();
        Employee Get(int empId);
        List<Employee> Get();
        int UpdateEmployee(int id);
        int DeleteEmployee(int id);
        int DeleteEmployees();
    }
}
