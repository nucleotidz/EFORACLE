﻿

using Boeing.EF.DEMO.Buisness;
using Boeing.EF.Repository.EDM;
using Boeing.EF.Repository.Repositries;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using Newtonsoft.Json;


using System;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;


namespace Boeing.EF.DEMO
{
    class Program
    {
        public static IConfiguration configuration = null;
        static void Main(string[] args)
        {
            Program.configuration = LoadConfiguration();

            IServiceCollection services = ConfigureServices();
            ServiceProvider serviceProvider = services.BuildServiceProvider();

            while (true)
            {
                using (IEmployeeService employeeService = serviceProvider.GetService<IEmployeeService>())
                {

                    Console.WriteLine("Enter 1 to save data");
                    Console.WriteLine("Enter 2 to save list data");
                    Console.WriteLine("Enter 3 to get data");
                    Console.WriteLine("Enter 4 to get all data");
                    Console.WriteLine("Enter 5 to update data");
                    Console.WriteLine("Enter 6 to delete data");
                    Console.WriteLine("Enter 7 to delete all data");
                    string input = Console.ReadLine();
                    switch (input)
                    {
                        case "1":
                            employeeService.Save();
                            break;
                        case "2":
                            employeeService.SaveAll();
                            break;
                        case "3":
                            employeeService.Get(1);
                            break;
                        case "4":
                            employeeService.Get();
                            break;
                        case "5":
                            Console.WriteLine("Enter Id");
                            employeeService.UpdateEmployee(Convert.ToInt32(Console.ReadLine()));
                            break;
                        case "6":
                            Console.WriteLine("Enter Id");
                            employeeService.DeleteEmployee(Convert.ToInt32(Console.ReadLine()));
                            break;
                        case "7":
                            employeeService.DeleteEmployees();
                            break;
                        default:
                            Console.WriteLine("Please give a valid input");
                            break;
                    }
                    Console.WriteLine("***********Operation Completed**************");
                }
            }
        }
        private static IServiceCollection ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddSingleton(configuration);
            string s = configuration.GetConnectionString("PMDBCON");
            services.AddTransient<IEmployeeRepository, EmployeeRepository>();
            services.AddTransient<IEmployeeService, EmployeeService>();
            services.AddSingleton<IConfiguration>(configuration);
            services.AddDbContext<DataContext>(options => options.UseOracle(configuration.GetConnectionString("PMDBCON")), ServiceLifetime.Transient);
            return services;
        }
        public static IConfiguration LoadConfiguration()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            return configurationBuilder.Build();
        }
    }
}
