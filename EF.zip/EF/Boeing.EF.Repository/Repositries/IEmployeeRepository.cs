﻿using System;
using System.Collections.Generic;
using System.Text;

using Boeing.EF.Repository.EDM;

namespace Boeing.EF.Repository.Repositries
{
    public interface IEmployeeRepository : IDisposable
    {
        int Save(Employee employee);
        int Save(List<Employee> employees);
        Employee Get(int empId);
        List<Employee> Get();
        int UpdateEmployee(int empId, string Name);
        int DeleteEmployee(int empId);
        int DeleteEmployees();
    }
}
