﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Linq;
using Boeing.EF.Repository.EDM;
using Microsoft.EntityFrameworkCore;

namespace Boeing.EF.Repository.Repositries
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private bool disposed = false;
        private readonly DataContext dataContext;
        public EmployeeRepository(DataContext dataContext)
        {
            this.dataContext = dataContext;
        }
        public int Save(Employee employee)
        {
            this.dataContext.Employees.Add(employee);
            return this.dataContext.SaveChanges();
        }
        public int Save(List<Employee> employees)
        {
            employees.ForEach(emp =>
            {
                this.dataContext.Employees.Add(emp);
            });
            return this.dataContext.SaveChanges();
        }
        public Employee Get(int empId)
        {
            Employee employee = (from emp in dataContext.Employees
                                 where emp.Id == empId
                                 select emp
                          ).FirstOrDefault();
            return employee;
        }
        public List<Employee> Get()
        {
            return dataContext.Employees.Include(x => x.Department).Include(x => x.Department.Cities).Select(x => x).ToList();

        }
        public int UpdateEmployee(int empId, string Name)
        {
            Employee employee = (from emp in dataContext.Employees
                                 where emp.Id == empId
                                 select emp
                         ).FirstOrDefault();
            if (employee != null)
            {
                employee.Name = Name;
                this.dataContext.Employees.Update(employee);
                return this.dataContext.SaveChanges();
            }
            return -1;
        }
        public int DeleteEmployee(int empId)
        {
            Employee employee = (from emp in dataContext.Employees.Include(x=>x.Department).Include(x=>x.Department.Cities)
                                 where emp.Id == empId
                                 select emp
                         ).FirstOrDefault();
            if (employee != null)
            {               
                this.dataContext.Employees.Remove(employee);
                return this.dataContext.SaveChanges();
            }
            return -1;
        }
        public int DeleteEmployees()
        {
           List< Employee> employees = (from emp in dataContext.Employees.Include(x => x.Department).Include(x => x.Department.Cities)

                                 select emp
                         ).ToList();
            if (employees != null && employees.Any())
            {
                this.dataContext.Employees.RemoveRange(employees);
                return this.dataContext.SaveChanges();
            }
            return -1;
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    if (this.dataContext != null)
                    {
                        this.dataContext.Dispose();
                    }
                }

                this.disposed = true;
            }
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
