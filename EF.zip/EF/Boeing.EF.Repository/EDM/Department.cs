﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Boeing.EF.Repository.EDM
{
    public class Department
    {
        public int Id { get; set; }
        public int EmpId { get; set; }
        public string DeptName { get; set; }
        public virtual Employee Employee { get; set; }

        public virtual ICollection<City> Cities { get; set; }
    }
}
