﻿using System;
using System.Collections.Generic;
using System.Text;

using Boeing.EF.Repository.Configuration;

using Microsoft.EntityFrameworkCore;

namespace Boeing.EF.Repository.EDM
{
    public class DataContext : DbContext
    {

        public DataContext(DbContextOptions<DataContext> options)
    : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new EmployeeConfig());
            modelBuilder.ApplyConfiguration(new DepartmentConfig());
            modelBuilder.ApplyConfiguration(new CityConfig());
        }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<City> Cities { get; set; }

    }
}
