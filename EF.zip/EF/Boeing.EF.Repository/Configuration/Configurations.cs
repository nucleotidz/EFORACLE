﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Boeing.EF.Repository.EDM;
using Microsoft.EntityFrameworkCore.ValueGeneration;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace Boeing.EF.Repository.Configuration
{
    public class EmployeeConfig : IEntityTypeConfiguration<Employee>
    {
        public void Configure(EntityTypeBuilder<Employee> modelBuilder)
        {
            modelBuilder.Property(column => column.Id).HasColumnName("ID").IsRequired().ValueGeneratedOnAdd().HasValueGenerator((_, __) => new SequenceValueGenerator("SEQ_TBLEMPLOYEE"));
            modelBuilder.Property(column => column.Name).HasColumnName("NAME").IsRequired();
            modelBuilder.Property(column => column.Email).HasColumnName("EMAIL").IsRequired();
            modelBuilder.Property(column => column.Phone).HasColumnName("PHONE");
            modelBuilder.HasKey(k => k.Id);
            
            modelBuilder.HasOne(fk => fk.Department).WithOne(fk => fk.Employee).HasForeignKey<Department>(fk=>fk.EmpId);
      
            modelBuilder.ToTable("TBLEMPLOYEE");
        }
    }
    public class DepartmentConfig : IEntityTypeConfiguration<Department>
    {
        public void Configure(EntityTypeBuilder<Department> modelBuilder)
        {
            modelBuilder.Property(column => column.Id).HasColumnName("ID").IsRequired().ValueGeneratedOnAdd().HasValueGenerator((_, __) => new SequenceValueGenerator("SEQ_TBLDEPARTMENT"));
            modelBuilder.Property(column => column.DeptName).HasColumnName("DEPTNAME").IsRequired();
            modelBuilder.Property(column => column.EmpId).HasColumnName("EMPID").IsRequired();           
            modelBuilder.HasKey(k => k.Id);          
            modelBuilder.HasOne(fk => fk.Employee).WithOne(fk => fk.Department).HasForeignKey<Department>(fk => fk.EmpId);
            modelBuilder.HasMany(fk => fk.Cities).WithOne(fk => fk.Department).HasForeignKey(fk=>fk.DepId);
            modelBuilder.ToTable("TBLDEPARTMENT");
        }
    }
    public class CityConfig : IEntityTypeConfiguration<City>
    {
        public void Configure(EntityTypeBuilder<City> modelBuilder)
        {
            modelBuilder.Property(column => column.Id).HasColumnName("ID").IsRequired().ValueGeneratedOnAdd().HasValueGenerator((_, __) => new SequenceValueGenerator("SEQ_TBLCITY"));
            modelBuilder.Property(column => column.DepId).HasColumnName("DEPID").IsRequired();
            modelBuilder.Property(column => column.Name).HasColumnName("CITY").IsRequired();
            modelBuilder.HasKey(k => k.Id);
            modelBuilder.HasOne(fk => fk.Department).WithMany(fk => fk.Cities).HasForeignKey(fk => fk.DepId);
            modelBuilder.ToTable("TBLCITY");
        }
    }
    internal class SequenceValueGenerator : ValueGenerator<int>
    {
        private string _sequenceName;

        public SequenceValueGenerator( string sequenceName)
        {
        
            _sequenceName = sequenceName;
        }

        public override bool GeneratesTemporaryValues => false;

        public override int Next(EntityEntry entry)
        {
            using (var command = entry.Context.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = $"SELECT {_sequenceName}.NEXTVAL FROM DUAL";
                entry.Context.Database.OpenConnection();
                using (var reader = command.ExecuteReader())
                {
                    reader.Read();
                    return reader.GetInt32(0);
                }
            }
        }
    }
}
